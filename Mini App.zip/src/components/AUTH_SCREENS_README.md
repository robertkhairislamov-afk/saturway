# Экраны Авторизации Saturway — Ocean Edition 🌊

Набор из 3 полностью переработанных экранов для авторизации в Telegram Mini App с погружающей океанской тематикой.

## 🌊 Что нового в версии 2.0

### Океанские эффекты
- ✨ **Анимированные волны** - реалистичные SVG-волны в фоне
- 🫧 **Плавающие пузырьки** - 15 случайно размещенных пузырьков воздуха
- 🌟 **Подводные лучи света** - динамическое освещение сверху
- ⭐ **Звездное небо** - для темной темы (ночной океан)
- 💫 **Backdrop blur** - эффект глубины воды
- 🌈 **Ripple-эффект** - волны при нажатии кнопок

### Новые компоненты
- `OceanBackground.tsx` - универсальный океанский фон (3 варианта)
- `RippleButton.tsx` - кнопка с эффектом волны при нажатии
- `OceanIllustrations.tsx` - SVG иллюстрации (медузы, рыбы, кораллы)

## 📱 Компоненты

### 1. LoadingScreen.tsx
**Первый экран при запуске приложения**

Функции:
- Океанский градиентный фон с пузырьками
- Подводные лучи света (8 лучей)
- Логотип с плавающей анимацией и свечением
- Улучшенный спиннер с пульсацией
- Меняющийся текст с тенями
- Автоматически вызывает `onComplete` через 3 секунды

Океанские эффекты:
- Variant: `gradient`
- Пузырьки: включены
- Звезды: включены (для темной темы)

Использование:
```tsx
<LoadingScreen onComplete={() => console.log('Loading done')} />
```

### 2. PermissionScreen.tsx
**Запрос разрешений на уведомления**

Функции:
- Волновой фон с анимированными SVG-волнами
- Иконка с пульсирующим кольцом и свечением
- Карточка преимуществ с backdrop-blur
- RippleButton для основного действия
- Микро-анимация при hover/tap

Океанские эффекты:
- Variant: `waves`
- Пузырьки: включены
- Звезды: включены
- Backdrop blur на карточках

Использование:
```tsx
<PermissionScreen 
  onAllow={() => enableNotifications()} 
  onSkip={() => skipPermissions()} 
/>
```

### 3. ErrorScreen.tsx
**Экран ошибки**

Функции:
- Глубокий океанский фон
- Анимированная иконка с покачиванием и пульсацией
- RippleButton для retry
- Улучшенный блок с советами (backdrop-blur)
- Плавные микро-интеракции

Океанские эффекты:
- Variant: `deep`
- Пузырьки: включены
- Звезды: включены
- Полупрозрачные карточки

Использование:
```tsx
<ErrorScreen 
  errorCode="AUTH001"
  errorMessage="Не удалось подключиться..."
  onRetry={() => retryAuth()}
  onSupport={() => openSupport()}
/>
```

### 4. OceanBackground.tsx
**Универсальный океанский фон (новый компонент)**

Варианты:
- `gradient` - плавный градиент (для LoadingScreen)
- `waves` - анимированные волны (для PermissionScreen)
- `deep` - глубокий океан (для ErrorScreen)

Параметры:
```tsx
interface OceanBackgroundProps {
  variant?: 'gradient' | 'waves' | 'deep';
  showBubbles?: boolean;      // Показывать пузырьки
  showStars?: boolean;         // Показывать звезды (темная тема)
  children?: React.ReactNode;
}
```

Особенности:
- Автоматически определяет светлую/темную тему
- 15 анимированных пузырьков разного размера
- 50 мерцающих звезд для темной темы
- 6 подводных лучей света
- Отслеживание изменений темы в реальном времени

Использование:
```tsx
<OceanBackground variant="gradient" showBubbles={true} showStars={true}>
  <YourContent />
</OceanBackground>
```

### 5. RippleButton.tsx
**Кнопка с волновым эффектом (новый компонент)**

Функции:
- Анимированный ripple-эффект при клике
- Расширяется и исчезает за 600ms
- Поддержка множественных кликов
- Автоматическая очистка старых ripple

Использование:
```tsx
<RippleButton
  onClick={handleClick}
  className="bg-gradient-to-r from-[#4A9FD8] to-[#52C9C1]"
>
  Нажми меня
</RippleButton>
```

### 6. OceanIllustrations.tsx
**SVG иллюстрации в океанском стиле (новый компонент)**

Компоненты:
- `JellyfishIllustration` - анимированная медуза
- `WaveIllustration` - волны
- `FishIllustration` - плавающая рыбка
- `BubbleGroup` - группа пузырьков
- `CoralIllustration` - кораллы

Использование:
```tsx
<JellyfishIllustration className="h-32 w-32" />
<FishIllustration className="h-16 w-16" delay={2} />
<WaveIllustration className="w-full h-20" />
```

### 7. AuthFlow.tsx
**Управляет потоком авторизации**

Порядок экранов:
1. LoadingScreen → (3 секунды)
2. PermissionScreen → (пользователь выбирает)
3. Завершение (вызывает onComplete)

Если `simulateError = true`, переходит на ErrorScreen.

Использование:
```tsx
<AuthFlow 
  onComplete={() => startApp()} 
  simulateError={false}
/>
```

### 8. AuthScreensDemo.tsx
**Демонстрационное меню для просмотра экранов**

Обновлено:
- Океанский фон с пузырьками
- Улучшенные кнопки с backdrop-blur
- Обновленный список особенностей
- Версия 2.0 • Ocean Edition

Использование:
```tsx
// В App.tsx установите DEMO_MODE = true
const DEMO_MODE = true;

if (DEMO_MODE) {
  return <AuthScreensDemo />;
}
```

## 🎨 Дизайн-система

### Цвета
- **Основной градиент**: `from-[#4A9FD8] to-[#52C9C1]`
- **Фон загрузки**: `from-[#4A9FD8] via-[#5AB5E8] to-[#52C9C1]`
- **Фон волн**: `from-[#0d1b2a] via-[#1b3a52] to-[#2C4A5F]` (dark)
- **Глубокий океан**: `from-[#2C7DA0] to-[#4A9FD8]`
- **Ошибка**: `#FF6B6B` (мягкий красный)
- **Успех**: `#52C9C1` (бирюзовый)
- **Пузырьки**: `white/20` (светлая), `white/10` (темная)

### Эффекты
- **Backdrop blur**: `blur-[1px]`, `blur-md`, `blur-sm`
- **Box shadow**: `0 8px 24px rgba(74, 159, 216, 0.3)`
- **Text shadow**: `0 2px 10px rgba(0,0,0,0.2)`
- **Glow**: `drop-shadow(0px 20px 60px rgba(74, 159, 216, 0.5))`

### Типографика
- **Заголовок H1**: 24-32px, Bold (700)
- **Основной текст**: 14-16px, Regular (400)
- **Мелкий текст**: 12-13px, Regular (400)
- **Код ошибки**: 12px, Monospace

### Анимации
- **Fade in**: 0.5-0.8s, ease-out
- **Scale**: от 0.5 до 1.0
- **Float**: y: [0, -15, 0], 3s, infinite
- **Pulse**: scale [1, 1.3, 1], opacity [0.8, 0, 0.8], 2s
- **Ripple**: scale 300px, opacity 0, 0.6s
- **Waves**: 8-10s, infinite, ease-in-out
- **Bubbles**: 10-18s, infinite, linear
- **Light rays**: opacity [0.2, 0.5, 0.2], 4s

### Отступы
- **Padding экранов**: 24px
- **Margin между секциями**: 24-32px
- **Отступ от иконок**: 12-16px

## 🌓 Темная тема

Все компоненты автоматически адаптируются:
- Используют Tailwind CSS переменные (`bg-background`, `text-foreground`)
- Градиенты остаются яркими на обеих темах
- Океанский фон меняется с голубого на глубокий темно-синий
- В темной теме появляются звезды (ночной океан)
- Пузырьки становятся менее заметными
- Backdrop blur создает эффект глубины

## 📱 Адаптивность

Экраны оптимизированы для:
- **Минимальная ширина**: 320px (iPhone SE)
- **Максимальная ширина**: 428px (iPhone 14 Pro Max)
- **Безопасные зоны**: учтены отступы для notch и bottom bar
- **Touch-friendly**: кнопки высотой 52px минимум

## 🔧 Интеграция

### Вариант 1: Полный поток авторизации
```tsx
// App.tsx
const [showAuth, setShowAuth] = useState(true);

if (showAuth) {
  return <AuthFlow onComplete={() => setShowAuth(false)} />;
}
```

### Вариант 2: Отдельные экраны
```tsx
// Собственная логика управления
const [step, setStep] = useState('loading');

switch (step) {
  case 'loading':
    return <LoadingScreen onComplete={() => setStep('permission')} />;
  case 'permission':
    return <PermissionScreen onAllow={...} onSkip={...} />;
  case 'error':
    return <ErrorScreen onRetry={...} />;
}
```

### Вариант 3: Использование океанского фона отдельно
```tsx
// В любом компоненте приложения
<OceanBackground variant="waves" showBubbles={true}>
  <YourContent />
</OceanBackground>
```

## 🎯 Локализация

Все тексты можно легко заменить:

```tsx
const texts = {
  ru: {
    loading: ['Подключаемся...', 'Секунду...'],
    permission: {
      title: 'Включить уведомления?',
      allow: 'Включить',
      skip: 'Позже'
    },
    error: {
      title: 'Что-то пошло не так',
      retry: 'Попробовать снова'
    }
  },
  en: {
    loading: ['Connecting...', 'One moment...'],
    permission: {
      title: 'Enable notifications?',
      allow: 'Enable',
      skip: 'Maybe later'
    },
    error: {
      title: 'Something went wrong',
      retry: 'Try again'
    }
  }
};
```

## 📦 Зависимости

- `motion/react` - анимации (Motion)
- `lucide-react` - иконки (Bell, AlertCircle, RefreshCw, MessageCircle, Check)
- Компоненты UI: `Button` (из shadcn/ui)

## ✨ Особенности v2.0

1. **Погружающие анимации** - океанские эффекты с пузырьками и волнами
2. **Подводные лучи** - динамическое освещение
3. **Ripple-эффект** - волны при нажатии кнопок
4. **Backdrop blur** - эффект глубины воды
5. **Темная тема со звездами** - ночной океан
6. **Адаптивный дизайн** - работает на всех размерах экранов
7. **Dark mode ready** - автоматическая поддержка темной темы
8. **Accessibility** - semantic HTML, ARIA labels
9. **Производительность** - оптимизированные SVG и CSS анимации
10. **UX** - понятные сообщения и плавные интеракции
11. **Переиспользуемые компоненты** - OceanBackground для всего приложения

## 🎭 Использование иллюстраций

Можно добавить океанские иллюстрации в любой экран:

```tsx
import { JellyfishIllustration, FishIllustration } from './OceanIllustrations';

// Добавить медузу в угол
<div className="absolute top-10 right-10 opacity-30">
  <JellyfishIllustration className="h-32 w-32" />
</div>

// Добавить плавающую рыбку
<div className="absolute bottom-20 left-10 opacity-40">
  <FishIllustration className="h-16 w-16" delay={1} />
</div>
```

## 🚀 Следующие шаги

1. ✅ Океанские эффекты (волны, пузырьки) — **ГОТОВО**
2. ✅ Подводные лучи света — **ГОТОВО**
3. ✅ Ripple-эффект на кнопках — **ГОТОВО**
4. ✅ Иллюстрации (медузы, рыбы) — **ГОТОВО**
5. ✅ Звездное небо для темной темы — **ГОТОВО**
6. Интегрировать с Telegram WebApp API
7. Добавить реальный запрос уведомлений через браузер API
8. Подключить систему аналитики
9. Добавить больше вариантов ошибок (нет сети, 404, 500)
10. Реализовать retry logic с exponential backoff
11. Добавить haptic feedback для Telegram

## 🎨 Кастомизация

### Изменить количество пузырьков
```tsx
// В OceanBackground.tsx, строка 38
const bubbles = Array.from({ length: 20 }, (_, i) => ({
  // увеличено с 15 до 20
```

### Изменить цвета градиента
```tsx
// Светлая тема
className="bg-gradient-to-b from-[#4A9FD8] via-[#5AB5E8] to-[#52C9C1]"

// Темная тема
className="bg-gradient-to-b from-[#0d1b2a] via-[#1b3a52] to-[#2C4A5F]"
```

### Добавить свои иллюстрации
```tsx
// В OceanIllustrations.tsx добавьте новый компонент
export function SharkIllustration({ className = '' }: { className?: string }) {
  return (
    <motion.svg className={className} viewBox="0 0 100 100">
      {/* Ваш SVG код */}
    </motion.svg>
  );
}
```

---

**Версия**: 2.0.0 — Ocean Edition 🌊  
**Дата обновления**: Ноябрь 2025  
**Автор**: Saturway Team  
**Философия**: Дисциплина через безмятежность океана
