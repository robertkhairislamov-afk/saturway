# 🌊 Ocean Accents Components

Коллекция океанских визуальных акцентов для Saturway — тонкие анимации и эффекты, которые добавляют глубину и атмосферность приложению.

## 📦 Компоненты

### 1. FloatingBubbles
Анимированные пузырьки, плавающие вверх по экрану.

**Использование:**
```tsx
import { FloatingBubbles } from './components/FloatingBubbles';

<FloatingBubbles 
  count={6}           // Количество пузырьков (по умолчанию: 8)
  minSize={15}        // Минимальный размер (по умолчанию: 15)
  maxSize={35}        // Максимальный размер (по умолчанию: 35)
  opacity={0.12}      // Прозрачность (по умолчанию: 0.15)
  className=""        // Дополнительные классы
/>
```

**Примеры:**
```tsx
// Основной фон приложения - тонкие пузырьки
<FloatingBubbles count={6} opacity={0.12} />

// Больше пузырьков для специальных секций
<FloatingBubbles count={12} opacity={0.2} />

// Крупные редкие пузырьки
<FloatingBubbles count={4} minSize={30} maxSize={60} />
```

### 2. GradientHeader
Красивый градиентный заголовок с анимированными декоративными элементами.

**Использование:**
```tsx
import { GradientHeader } from './components/GradientHeader';
import { Waves } from 'lucide-react';

<GradientHeader
  title="Заголовок"
  subtitle="Подзаголовок"           // Опционально
  icon={<Waves className="h-6 w-6" />}  // Опционально
  variant="ocean"                    // ocean | sky | turquoise
  showDecoration={true}              // Показывать декор (по умолчанию: true)
  className=""                       // Дополнительные классы
/>
```

**Варианты градиентов:**
- `ocean` - от #4A9FD8 через #5AB5E8 до #52C9C1 (основной)
- `sky` - от #5AB5E8 через #4ECDC4 до #52C9C1 (светлее)
- `turquoise` - от #52C9C1 через #4ECDC4 до #4A9FD8 (бирюзовый)

**Примеры:**
```tsx
// Полный заголовок с иконкой
<GradientHeader
  title={`Привет, ${userName}!`}
  subtitle="Добро пожаловать обратно"
  icon={<Sparkles className="h-6 w-6" />}
  variant="ocean"
/>

// Простой заголовок без декора
<GradientHeader
  title="Задачи"
  variant="sky"
  showDecoration={false}
/>
```

### 3. AnimatedOceanCard
Карточка с анимированными волновыми эффектами и свечением при наведении.

**Использование:**
```tsx
import { AnimatedOceanCard } from './components/AnimatedOceanCard';

<AnimatedOceanCard
  delay={0}           // Задержка анимации (по умолчанию: 0)
  showWaves={true}    // Показывать волны при hover (по умолчанию: true)
  showGlow={true}     // Показывать свечение при hover (по умолчанию: true)
  className=""        // Дополнительные классы
>
  <div className="p-6">
    {/* Ваш контент */}
  </div>
</AnimatedOceanCard>
```

**Примеры:**
```tsx
// Стандартная карточка с эффектами
<AnimatedOceanCard delay={0.1}>
  <div className="p-6">
    <h3>Заголовок</h3>
    <p>Контент карточки</p>
  </div>
</AnimatedOceanCard>

// Список карточек с каскадной анимацией
{items.map((item, index) => (
  <AnimatedOceanCard key={item.id} delay={index * 0.05}>
    <div className="p-4">{item.content}</div>
  </AnimatedOceanCard>
))}

// Только свечение, без волн
<AnimatedOceanCard showWaves={false}>
  {/* контент */}
</AnimatedOceanCard>
```

### 4. OceanAccents
Фоновые океанские акценты - градиентные шары и пульсирующие круги.

**Использование:**
```tsx
import { OceanAccents } from './components/OceanAccents';

<OceanAccents
  variant="subtle"          // subtle | medium | vibrant
  showRipples={true}        // Показывать пульсацию (по умолчанию: true)
  showGradientOrbs={true}   // Показывать градиентные шары (по умолчанию: true)
  className=""              // Дополнительные классы
/>
```

**Варианты интенсивности:**
- `subtle` - opacity 0.03 (основной фон приложения)
- `medium` - opacity 0.05 (отдельные секции)
- `vibrant` - opacity 0.08 (героические секции)

**Примеры:**
```tsx
// Фон всего приложения
<div className="relative min-h-screen">
  <OceanAccents variant="subtle" />
  <div className="relative z-10">
    {/* контент */}
  </div>
</div>

// Специальная секция с более яркими эффектами
<div className="relative">
  <OceanAccents variant="medium" />
  <div className="relative z-10">
    {/* контент */}
  </div>
</div>

// Только градиентные шары
<OceanAccents variant="medium" showRipples={false} />
```

### 5. OceanDivider
Декоративные разделители секций с океанскими эффектами.

**Использование:**
```tsx
import { OceanDivider } from './components/OceanDivider';

<OceanDivider
  variant="gradient"    // wave | dots | gradient | simple
  className=""          // Дополнительные классы
/>
```

**Варианты:**
- `wave` - Анимированная волна
- `dots` - Три пульсирующие точки
- `gradient` - Горизонтальная градиентная линия
- `simple` - Простая линия с градиентом

**Примеры:**
```tsx
// Между секциями
<OceanDivider variant="gradient" className="my-8" />

// Анимированная волна
<OceanDivider variant="wave" className="my-6" />

// Минималистичные точки
<OceanDivider variant="dots" />
```

### 6. PulsingDot
Пульсирующий индикатор для статусов и уведомлений.

**Использование:**
```tsx
import { PulsingDot } from './components/PulsingDot';

<PulsingDot
  color="#4A9FD8"      // Цвет (по умолчанию: #4A9FD8)
  size="md"            // sm | md | lg
  className=""         // Дополнительные классы
/>
```

**Примеры:**
```tsx
// Индикатор активности
<div className="flex items-center gap-2">
  <PulsingDot color="#52C9C1" size="sm" />
  <span>Онлайн</span>
</div>

// Уведомление
<div className="relative">
  <Bell className="h-6 w-6" />
  <PulsingDot 
    color="#FF6B6B" 
    size="sm" 
    className="absolute -top-1 -right-1"
  />
</div>
```

## 🎨 Цветовая схема

Все компоненты используют единую океанскую палитру:
- `#4A9FD8` - Ocean Blue (основной синий)
- `#5AB5E8` - Sky Blue (небесно-голубой)
- `#52C9C1` - Turquoise (бирюзовый)
- `#4ECDC4` - Cyan Bright (яркий циан)

## 💡 Рекомендации по использованию

### Основное приложение (App.tsx)
```tsx
<div className="relative min-h-screen bg-background pb-20">
  {/* Тонкие фоновые эффекты */}
  <OceanAccents variant="subtle" />
  <FloatingBubbles count={6} opacity={0.12} />
  
  {/* Контент приложения */}
  <div className="relative z-10">
    {/* ... */}
  </div>
</div>
```

### Dashboard с океанскими акцентами
```tsx
<div className="space-y-6">
  {/* Градиентный заголовок */}
  <GradientHeader
    title={`Привет, ${userName}!`}
    subtitle="Начните свой продуктивный день"
    variant="ocean"
  />

  {/* Статистика с анимированными карточками */}
  <div className="grid gap-4 sm:grid-cols-2">
    {stats.map((stat, index) => (
      <AnimatedOceanCard key={index} delay={index * 0.1}>
        <div className="p-6">
          {/* контент статистики */}
        </div>
      </AnimatedOceanCard>
    ))}
  </div>
</div>
```

### Список задач
```tsx
<div className="space-y-6">
  <GradientHeader
    title="Мои задачи"
    subtitle="5 активных, 3 завершённых"
    icon={<ListTodo className="h-6 w-6" />}
    variant="sky"
  />

  <div className="space-y-2">
    {tasks.map((task, index) => (
      <AnimatedOceanCard key={task.id} delay={0.05 * index} showWaves={false}>
        <div className="p-4">
          {/* контент задачи */}
        </div>
      </AnimatedOceanCard>
    ))}
  </div>
</div>
```

## 🎬 Анимации

Все компоненты используют Motion (Framer Motion) для плавных анимаций:
- **FloatingBubbles**: Линейное движение вверх с небольшим горизонтальным смещением
- **GradientHeader**: Spring анимация для иконки, fade-in для текста
- **AnimatedOceanCard**: Spring анимация появления, wave pattern при hover
- **OceanAccents**: Медленные ease-in-out анимации для шаров и пульсации

## 🔧 Кастомизация

### Изменение цветов
Цвета определены в `/styles/globals.css`:
```css
--ocean-blue: #4A9FD8;
--sky-blue: #5AB5E8;
--turquoise: #52C9C1;
```

### Создание собственного варианта GradientHeader
```tsx
// В GradientHeader.tsx добавьте новый вариант
const gradients = {
  ocean: 'from-[#4A9FD8] via-[#5AB5E8] to-[#52C9C1]',
  sky: 'from-[#5AB5E8] via-[#4ECDC4] to-[#52C9C1]',
  turquoise: 'from-[#52C9C1] via-[#4ECDC4] to-[#4A9FD8]',
  custom: 'from-[ВАШ_ЦВЕТ] via-[ВАШ_ЦВЕТ] to-[ВАШ_ЦВЕТ]',
};
```

## 📊 Производительность

- **FloatingBubbles**: ~6-8 пузырьков оптимально для производительности
- **OceanAccents**: Используйте "subtle" для основного фона
- **AnimatedOceanCard**: Ограничивайте задержки до 0.5s для больших списков

## 🎯 Демо

Для просмотра всех компонентов в действии:
```tsx
import { OceanAccentsDemo } from './components/OceanAccentsDemo';
```

## 📝 Примечания

- Все компоненты поддерживают тёмную тему
- Анимации автоматически оптимизируются для производительности
- Компоненты полностью responsive и работают на всех размерах экранов
- Используйте pointer-events-none для фоновых элементов